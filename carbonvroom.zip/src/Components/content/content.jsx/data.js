exports.item=[{
    id: "option-1",
    text: "Option 1"},
  {
    id: "option-2",
    text: "Option 2"
  },
  {
    id: "option-3",
    text: "Option 3"
  },
  {
    id: "option-4",
    text: "Option 4"
  },
  {
    id: "option-5",
    text:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Vitae, aliquam. Blanditiis quia nemo enim voluptatibus quos ducimus porro molestiae nesciunt error cumque quaerat, tempore vero unde eum aperiam eligendi repellendus."
  }
]